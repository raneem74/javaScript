var arr=[11,22,33,44,55,66]
arr[4]
arr[5]
//length=largestIndex+1

arr[20]="abc";


console.log(arr.length);//21



var custArr=[];

custArr["usrName"]="Ali";
custArr["usrAge"]=10;
custArr["usrAddr"]="123 st.";
var usrID="ID";


custArr[usrID]="UI-123-43";//subscript notation
custArr["ID"]="UI-123-43";//subscript notation

custArr.ID;//dot notation
custArr.usrID;//dot notation//undefined















