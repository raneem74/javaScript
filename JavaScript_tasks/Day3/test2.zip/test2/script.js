var arr=[1,2,3,4,5,6]

arr[20] = "abc";

console.log(arr.length); // 21

console.log(arr);

console.log(arr[8]); //undefined
arr[8]=55;
console.log(arr[8]); //55

console.log(arr);
arr[100] = "hassan";
console.log(arr.length); //101  
// arr.length // see where the last defined value

newArr=[false, "", 90, [1,2,3,4,5]];
console.log(newArr);
console.log(newArr[3][1]);

newArr=[false, "", 90, [1,2,3,4,5,[33,44,55,66]]];
console.log(newArr);
console.log(newArr[3][5][0]);

var arr = [1,2,3,4,5,10,11,23,22]
console.log(arr.pop());
console.log(arr.push(9));
console.log(arr.reverse());
console.log(arr.shift());
console.log(arr.unshift(10));

console.log(arr.sort()); // sort with respect with unicode

var arr2 = arr;  // passed by refrence because they are objects
arr2.pop();
arr2.pop();
arr2.pop();
console.log(arr2);
console.log(arr);

// we can use loop
var arr3=[];
for(var i=0; i<arr.length;i++){
    arr3[i] = arr2[i];
}
console.log(arr3);
arr3.pop();
arr3.pop();
console.log(arr3);
console.log(arr);

console.log(arr.join("__"));
console.log(arr3);

var arr4 = [1,2,3,4,[5,6,7]];
console.log(arr4.join("_"));
console.log(arr4.flat().join("_"));
console.log(arr4.join("**"));   // return type of join function is string
console.log(arr4.join("**").split('*'));

var str = "this is a demo string";
console.log(str.split(""));
console.log(str.split("").join(""));

/*======================================Associative Array=======================================================*/

var custArr=[];
custArr["userName"] = "Ali";
custArr["age"] = 25;
custArr["address"] = "123 st.";

console.log(custArr);
console.log(custArr.length); //0
console.log(custArr[0]); // undefined
//custArr[0] = 9;
console.log(custArr[0]); 

console.log(custArr["userName"]); 
custArr["userName"] = "Kareem";

var usrID="ID";
custArr[usrID] = "UI-123-43";
console.log(custArr);
console.log("CustArr.ID: " + custArr.ID); //dot notation
console.log("CustArr.address: " +custArr.address); //dot notation
console.log("CustArr[ID]: " + custArr["ID"]); //subscript notation

console.log("arr.length: " +arr.length); 
console.log("arr[length]: " +arr["length"]);  //subscript notation
var x = "length";   console.log("arr[x] " +arr[x]);

console.log("print Elements in custArr");
for(i in custArr){
    //console.log(i);
    console.log(i + ": "+ custArr[i]);
}
/*======================================Associative Array=======================================================*/
var today = new Date();
console.log(today.getDate());
console.log(today);
today.setDate(3);
console.log(today);
console.log(today.getYear());
console.log(today.getFullYear());
//today.setFullYear()

console.log(today.toDateString());
console.log(today.toLocaleString());
console.log(today.toLocaleString("ar-Eg"));


// !! return boolean value
console.log(!!true);
console.log(!!"");
console.log(!!"abc");
//console.log(!!abc);
