var timerId;
function startTimer(){
    //    setTimeOut("alert('timer')", 2000); // will be called joust once
    // timerId= setInterval(execFun, 2000);  // put reference of the function to execute every time

    // the function only called here only so we can put the the execFun body here
    timerId= setInterval(function (x){ // anonymous function
        console.log(x);
        alert('timer');
    }, 2000, 10);
}

function stopTimer(){
    //    setTimeOut("alert('timer')", 2000);
    clearInterval(timerId);
}

/*
function execFun(){
    alert('timer');
}
*/
var timerId2;
function fun(){

    //
    alert("fun");
    //timerId = setInterval(fun,2000); // with every call a new timer set
    timerId2 = setTimeout(fun,2000); // will act such a start Timer with setInterval

}

var t = setInterval(function (){
    clearTimeout(timerId2)
}, 100000)
/*
fun |---|---|---|
    fun |---|---|---|
        fun |---|---|---|
            fun |---|---|---|
            ..............
*/